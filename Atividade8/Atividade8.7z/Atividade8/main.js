const respostas = [];

    document.getElementById("pesquisaForm").addEventListener("submit", function(e) {
      e.preventDefault();

      const idade = parseInt(document.getElementById("idade").value);
      const sexo = document.getElementById("sexo").value;
      const opiniao = parseInt(document.getElementById("opiniao").value);

      if (respostas.length >= 45) {
        alert("Limite de 45 respostas atingido.");
        return;
      }

      respostas.push({ idade, sexo, opiniao });
      alert("Resposta registrada!");
      this.reset();
    });

    function mostrarResultados() {
      if (respostas.length === 0) {
        document.getElementById("output").innerHTML = "Nenhuma resposta registrada ainda.";
        return;
      }

      const total = respostas.length;
      const somaIdades = respostas.reduce((acc, r) => acc + r.idade, 0);
      const mediaIdade = (somaIdades / total).toFixed(2);
      const maisVelho = Math.max(...respostas.map(r => r.idade));
      const maisNovo = Math.min(...respostas.map(r => r.idade));
      const pessimo = respostas.filter(r => r.opiniao === 1).length;
      const otimoBom = respostas.filter(r => r.opiniao === 3 || r.opiniao === 4).length;
      const porcentagemOtimoBom = ((otimoBom / total) * 100).toFixed(2);
      const mulheres = respostas.filter(r => r.sexo === "feminino").length;
      const homens = respostas.filter(r => r.sexo === "masculino").length;
      const outros = respostas.filter(r => r.sexo === "outros").length;

      document.getElementById("output").innerHTML = `
        <p>Média de idade: <strong>${mediaIdade}</strong></p>
        <p>Idade da pessoa mais velha: <strong>${maisVelho}</strong></p>
        <p>Idade da pessoa mais nova: <strong>${maisNovo}</strong></p>
        <p>Quantidade de pessoas que responderam "Péssimo": <strong>${pessimo}</strong></p>
        <p>Porcentagem que respondeu "Ótimo" ou "Bom": <strong>${porcentagemOtimoBom}%</strong></p>
        <p>Número de mulheres: <strong>${mulheres}</strong></p>
        <p>Número de homens: <strong>${homens}</strong></p>
        <p>Número de outros: <strong>${outros}</strong></p>
        <p>Total de respostas: <strong>${total}</strong> / 45</p>
      `;
    }