var numero1 = parseFloat(prompt('Insira o número #1'));
var numero2 = parseFloat(prompt('Insira o número #2'));

const soma = () =>{
    return numero1 + numero2;
}

const subtracao = () =>{
    return numero1 - numero2;
}

const multiplicacao = () =>{
    return numero1 * numero2;
}

const divisao = () =>{
    return numero1/numero2;
}

const resto = () =>{
    return numero1%numero2;
}

alert("soma: " + soma());
alert("subtração: " + subtracao());
alert("multiplicação: " + multiplicacao());
alert("divisão: " + divisao());
alert("resto: " + resto());
