var nome = prompt('Insira o seu nome');
var numero1 = parseFloat(prompt('Insira o número #1'));
var numero2 = parseFloat(prompt('Insira o número #2'));
var numero3 = parseFloat(prompt('Insira o número #3'));
var numero4 = parseFloat(prompt('Insira o número #4'));

const media = ()=>{
    let soma = numero1 + numero2 + numero3 + numero4;

    return soma/4;
}

alert('A média dos 4 números é: ' + media());
