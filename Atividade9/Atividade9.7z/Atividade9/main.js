function testeMaiorNumero() {
    const a = parseFloat(prompt("Digite o primeiro número:"));
    const b = parseFloat(prompt("Digite o segundo número:"));
    const c = parseFloat(prompt("Digite o terceiro número:"));
    alert("Maior número: " + Math.max(a, b, c));
  }
  
  function ordenarCrescente(a, b, c) {
    return [a, b, c].sort((x, y) => x - y);
  }
  
  function testeOrdemCrescente() {
    const a = parseFloat(prompt("Digite o primeiro número:"));
    const b = parseFloat(prompt("Digite o segundo número:"));
    const c = parseFloat(prompt("Digite o terceiro número:"));
    alert("Ordem crescente: " + ordenarCrescente(a, b, c).join(", "));
  }
  
  function ehPalindromo(texto) {
    const str = texto.toUpperCase();
    return str === str.split('').reverse().join('');
  }
  
  function testePalindromo() {
    const palavra = prompt("Digite uma palavra:");
    const resultado = ehPalindromo(palavra) ? "é um palíndromo" : "não é um palíndromo";
    alert(`"${palavra}" ${resultado}.`);
  }
  
  function tipoTriangulo(a, b, c) {
    if (a + b > c && a + c > b && b + c > a) {
      if (a === b && b === c) return "Equilátero";
      if (a === b || a === c || b === c) return "Isósceles";
      return "Escaleno";
    } else {
      return "Não é um triângulo";
    }
  }
  
  function testeTriangulo() {
    const a = parseFloat(prompt("Lado A:"));
    const b = parseFloat(prompt("Lado B:"));
    const c = parseFloat(prompt("Lado C:"));
    alert("Resultado: " + tipoTriangulo(a, b, c));
  }