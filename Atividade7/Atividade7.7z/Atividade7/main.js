function getRandomNumber() {
    return Math.floor(Math.random() * 3) + 1;
}

function jogar(escolhaUsuario) {
    let numeroSorteado = getRandomNumber();
    let escolhas = { 1: "pedra", 2: "papel", 3: "tesoura" };
    let escolhaComputador = escolhas[numeroSorteado];

    let resultado = "";

    if (escolhaUsuario === escolhaComputador) {
        resultado = "Deu empate!";
    } 
    else if (
        (escolhaUsuario === "pedra" && escolhaComputador === "tesoura") ||
        (escolhaUsuario === "papel" && escolhaComputador === "pedra") ||
        (escolhaUsuario === "tesoura" && escolhaComputador === "papel")
    ) {
        resultado = "Você ganhou!";
    } 
    else {
        resultado = "Você perdeu!";
    }

    document.getElementById("resultado").innerHTML = `
        Você escolheu: <strong>${escolhaUsuario}</strong> <br>
        O computador escolheu: <strong>${escolhaComputador}</strong> <br>
        <p>${resultado}</p>
    `;
}
